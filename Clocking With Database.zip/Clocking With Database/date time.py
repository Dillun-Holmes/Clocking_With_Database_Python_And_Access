import tkinter as tk
import time
import pyodbc
from datetime import date

class ClockingProgram:
    def __init__(self, master):
        self.master = master
        master.title("Clocking Program")

        self.label = tk.Label(master, text="Press 'Start' to begin the clocking program.")
        self.label.pack()

        self.start_button = tk.Button(master, text="Start", command=self.start_clock)
        self.start_button.pack()

        self.stop_button = tk.Button(master, text="Stop", command=self.stop_clock, state="disabled")
        self.stop_button.pack()

        self.total_label = tk.Label(master, text="")
        self.total_label.pack()

        self.start_time = None
        self.end_time = None

        self.conn_str = (
            r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
            r"DBQ=C:\Users\dillu\OneDrive\Desktop\Foundation Python\Clocking With Database\time_ctu1.accdb;"
            r"DriverId=25;"
        )

    def start_clock(self):
        self.start_time = time.time()
        self.label.config(text="Press 'Stop' when you're done.")
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

    def stop_clock(self):
        self.end_time = time.time()
        total_time_seconds = self.end_time - self.start_time
        minutes, seconds = divmod(total_time_seconds, 60)
        hours, minutes = divmod(minutes, 60)
        total_time_formatted = f"{int(hours):02d}:{int(minutes):02d}:{seconds:.2f}"
        self.total_label.config(text=f"Total time: {total_time_formatted}")
        self.label.config(text="Press 'Start' to begin the clocking program.")
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        self.write_to_database(total_time_seconds)

    def write_to_database(self, total_time_seconds):
        today = date.today()
        conn = pyodbc.connect(self.conn_str)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO ClockingData ([Date], TotalTime) VALUES (?, ?)", (today.strftime("%Y-%m-%d"), total_time_seconds))
        conn.commit()
        cursor.close()
        conn.close()

if __name__ == "__main__":
    root = tk.Tk()
    clocking_program = ClockingProgram(root)
    root.mainloop()
